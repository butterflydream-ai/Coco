// Signed esbuild alias for `react/jsx-runtime`.
const runtime = globalThis.__cocoRaycastRuntime;
if (!runtime?.jsxRuntime) throw new Error("Coco pinned JSX runtime is unavailable");
export const { Fragment, jsx, jsxs } = runtime.jsxRuntime;
