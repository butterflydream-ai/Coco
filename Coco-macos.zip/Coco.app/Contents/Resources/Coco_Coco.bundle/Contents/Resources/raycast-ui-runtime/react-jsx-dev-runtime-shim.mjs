// Signed esbuild alias for `react/jsx-dev-runtime`.
const runtime = globalThis.__cocoRaycastRuntime;
if (!runtime?.jsxDevRuntime) throw new Error("Coco pinned JSX development runtime is unavailable");
export const { Fragment, jsxDEV } = runtime.jsxDevRuntime;
