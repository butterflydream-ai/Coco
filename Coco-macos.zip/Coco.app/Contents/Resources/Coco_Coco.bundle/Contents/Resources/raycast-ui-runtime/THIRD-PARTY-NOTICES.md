# Raycast UI runtime notices

The declarative compatibility runtime will materialise only the exact Node,
React, React reconciler, JSX runtime, and esbuild artefacts pinned by the
code-signed `toolchain-manifest.json`. Package-specific licence notices are
recorded with each verified toolchain cache entry before execution.
