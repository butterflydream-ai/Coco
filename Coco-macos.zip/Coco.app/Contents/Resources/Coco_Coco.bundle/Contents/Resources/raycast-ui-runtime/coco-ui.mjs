// Coco's first-party declarative facade. It emits the same host node names as
// @raycast/api, so native Coco offline tools and compatible Raycast tools share
// one protocol and renderer.

import React from "react";

const component = (name) => function CocoDeclarativeProtocolComponent(props = {}) {
  const { actions, children, ...safeProps } = props;
  return React.createElement(name, safeProps, ...[children, actions].filter((value) => value != null));
};

export const List = component("List");
export const ListSection = component("ListSection");
export const ListItem = component("ListItem");
export const Detail = component("Detail");
export const MetadataSection = component("MetadataSection");
export const MetadataValue = component("MetadataValue");
export const Form = component("Form");
export const TextField = component("TextField");
export const TextArea = component("TextArea");
export const PasswordField = component("PasswordField");
export const Checkbox = component("Checkbox");
export const Dropdown = component("Dropdown");
export const DropdownItem = component("DropdownItem");
export const DatePicker = component("DatePicker");
export const ActionPanel = component("ActionPanel");
export const ActionSection = component("ActionSection");
export const Action = component("Callback");
Action.SubmitForm = component("Callback");
Action.Push = component("Callback");
export const CopyToClipboard = component("Clipboard");
export const Paste = component("Paste");
export const Open = component("Open");
export const Fragment = component("Fragment");

export const __cocoUIDeclarativeVersion = "1";
