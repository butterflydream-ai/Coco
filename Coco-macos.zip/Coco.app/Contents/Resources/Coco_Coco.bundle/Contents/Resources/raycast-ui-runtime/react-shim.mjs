// Signed esbuild alias for extension imports of `react`. The runner installs
// this exact object from Task 2's verified private runtime before any compiled
// extension bundle is imported, so JSX/hooks and react-reconciler share one
// dispatcher identity.
const runtime = globalThis.__cocoRaycastRuntime;
if (!runtime?.React) throw new Error("Coco pinned React runtime is unavailable");
const React = runtime.React;

export default React;
export const {
  Children, Component, Fragment, PureComponent, StrictMode, Suspense, cloneElement,
  createContext, createElement, createFactory, createRef, forwardRef, isValidElement,
  lazy, memo, startTransition, use, useActionState, useCallback, useContext, useDebugValue,
  useDeferredValue, useEffect, useId, useImperativeHandle, useInsertionEffect, useLayoutEffect,
  useMemo, useOptimistic, useReducer, useRef, useState, useSyncExternalStore, useTransition,
  version,
} = React;
