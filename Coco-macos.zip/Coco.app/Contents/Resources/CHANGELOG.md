# Changelog

## [1.17.1] - 2026-08-18

### Fixed

- Use a clone-depth-independent, monotonic Sparkle build number above the
  currently published 1.16.7 build, so newer Coco releases can be discovered
  by existing installs whether they are built locally or by the signing runner.
- Publish the small signed update feed directly to Cloudflare Pages while
  serving release archives from the public GitHub Release, so an unreliable
  Pages large-file upload or hosted Actions billing failure cannot strand the
  live update feed.

## [1.17.0] - 2026-08-05

### Added

- Add Raycast migration for encrypted configuration, shortcuts, clipboard history, snippets, quick links, preferences, and conflict-aware import.
- Add a trusted offline Raycast command host with native List, Detail, Form, Action Panel, clipboard, storage, navigation, and user-confirmed URL actions.
- Add pinned Node 25 tooling, pure-JavaScript dependency resolution, source-policy scanning, isolated sessions, and packaged fresh-profile verification.

### Fixed

- Preserve physical runtime paths and compiler context across signed packaged launches.
- Harden Raycast compatibility checks, Swift 6 inference, startup framing, and fresh-profile probes.
- Keep imported Raycast commands' native clipboard replies working when Node and macOS canonicalize the same UUID with different letter case.
- Keep unsupported network, AI, native-module, arbitrary-shell, and unsafe UI capabilities rejected by the offline policy.

All notable changes to Coco, newest first. One `## [version] - date`
section per release; the maintainer adds the new section in the release
commit *before* tagging `vX.Y.Z`.

## [1.16.7] - 2026-08-02
### Fixed
- Coco no longer asks an already-activated Mac to activate again after it
  has been offline for a while. Activation codes grant a perpetual license,
  but it was still being held to a 72-hour offline check-in window.
- Coco now re-checks its license as soon as the network comes back, instead
  of only at launch.
- When the license is fine but the license server can't be reached, the
  prompt says so and offers a retry rather than claiming the trial ended.

## [1.16.6] - 2026-07-16
### Fixed
- Coco no longer quits when macOS 27 beta (26A5378n) throws an exception
  inside the menu-bar status-item wake path after lid-open/unlock. The
  ViewBridge `NSRemoteView` exception is now caught and logged instead of
  aborting the app.

## [1.16.4] - 2026-07-10
### Fixed
- Lid-close Keep Awake now directs users to enable **Coco** under macOS
  Background Items instead of asking them to find an invisible helper.
- Recovery reports whether an official signed update, macOS approval, or a
  helper reinstall is required; it no longer fails silently.
- Stable releases require a matching Developer ID signature for both Coco and
  its privileged helper, preventing public packages that cannot use lid-close
  protection.

### Changed
- Lid-close protection now relies on the MacBook's natural panel-off behavior
  and no longer forces a display-power transition that could leave audio or
  microphone hardware stuck after reopening the lid.
- Idle screen style is configured separately from lid-close protection.

## [1.7.0] - 2026-05-19
### Added
- Native macOS Liquid Glass refractive rim on the launcher panel.
- Calculator accepts a standalone `x` as multiply (`2x3`, `2 x 3`).
### Changed
- Mode switch resolves its colors live for light/dark appearance.
- Action menu no longer dims the result list.
### Fixed
- "Already up to date" / canceled update checks no longer surface as failures.
