# Changelog

All notable changes to Coco, newest first. One `## [version] - date`
section per release; the maintainer adds the new section in the release
commit *before* tagging `vX.Y.Z`.

## [1.16.6] - 2026-07-16
### Fixed
- Coco no longer quits when macOS 27 beta (26A5378n) throws an exception
  inside the menu-bar status-item wake path after lid-open/unlock. The
  ViewBridge `NSRemoteView` exception is now caught and logged instead of
  aborting the app.

## [1.16.4] - 2026-07-10
### Fixed
- Lid-close Keep Awake now directs users to enable **Coco** under macOS
  Background Items instead of asking them to find an invisible helper.
- Recovery reports whether an official signed update, macOS approval, or a
  helper reinstall is required; it no longer fails silently.
- Stable releases require a matching Developer ID signature for both Coco and
  its privileged helper, preventing public packages that cannot use lid-close
  protection.

### Changed
- Lid-close protection now relies on the MacBook's natural panel-off behavior
  and no longer forces a display-power transition that could leave audio or
  microphone hardware stuck after reopening the lid.
- Idle screen style is configured separately from lid-close protection.

## [1.7.0] - 2026-05-19
### Added
- Native macOS Liquid Glass refractive rim on the launcher panel.
- Calculator accepts a standalone `x` as multiply (`2x3`, `2 x 3`).
### Changed
- Mode switch resolves its colors live for light/dark appearance.
- Action menu no longer dims the result list.
### Fixed
- "Already up to date" / canceled update checks no longer surface as failures.
