# Changelog

## [Unreleased]

## [1.18.0] - 2026-08-24

### Added

- Pin apps to the top of the zero-query list: right-click → Pin, or ⌘K menu.
  Pinned apps sort to the top across all filter views as a sorting rule.
- A filter bar above the app list: Recommended (usage-ranked top apps) / All
  (every installed app) / Running / Recent. The first tab is Recommended by
  default; All is a separate tab that lists truly all apps.
- Persist the calculator tape to disk as a tree instead of clearing it when the
  panel hides. ↩ on a history row continues from it as a branch, ⌘↩ starts a new
  trunk, ⌫ deletes a node, and Settings ▸ Data can clear the history.
- Pin a calculation into a small always-on-top window with ⌘D. It shares the
  panel's tape and is a full input surface, not a read-only receipt.

### Changed

- Redesign the settings panel: 16 flat sidebar tabs become 12 grouped tabs under
  four section headers (Basics / Features / Extensions / System). General absorbs
  Appearance, Screenshot, Currency, and Data. Commands absorbs App Aliases via a
  segmented tab. AI Models and Voice merge into AI & Voice. Keep Awake is
  extracted into its own pane.
- Replace the app filter bar's Pinned chip with a Recommended / All split.
  Pinned apps are no longer a separate filter — they float to the top of every
  view.
- Simplify the bottom action bar: the right side now shows only the ⌘K menu
  shortcut instead of multiple action chips.
- Give the launcher's three tabs one shared maximum height, derived from the app
  list, so switching Apps / Clipboard / Tools no longer resizes the window.
- Anchor the panel's top edge to that height, so a narrowing query shrinks the
  panel from the bottom instead of walking it down the screen.
- Replace the Favorites tab with Tools: a single-column grouped list of the
  built-in features, fully keyboard operable. Favorites becomes a filter inside
  the clipboard tab.
- Quieten the mode switcher: no groove, no raised thumb, bare symbols with the
  selected one switching to its filled variant.
- The Favorites chip in the clipboard filter bar is now a symbol toggle button
  (star / star.fill) instead of a capsule chip.
- Widen the clipboard preview from 336pt to 368pt.

### Removed

- The ⌘1 / ⌘2 / ⌘3 tab shortcuts. Tab and ⇧Tab already cycle Apps / Clipboard /
  Tools in both directions.

### Fixed

- Prevent the panel from growing wider than 692pt when switching to the
  clipboard tab.
- Stop the panel recomputing its height on every summon, and stop the calculator
  tape rebuilding every row on every keystroke.
- Flush the calculator tape on quit, so the newest calculation is not lost.
- Stop a hand-typed `calc`, `rate` or `unit` from shadowing app search.
- Remove background pad from mode switch selected state.

## [1.17.2] - 2026-08-18

### Fixed

- Publish the macOS package with the Developer ID signature required by the
  privileged helper, so lid-close protection remains available after update.
- Make headless Mac release publishing use the local Sparkle signing key and
  immutable public release archives.

## [1.17.1] - 2026-08-18

### Fixed

- Use a clone-depth-independent, monotonic Sparkle build number above the
  currently published 1.16.7 build, so newer Coco releases can be discovered
  by existing installs whether they are built locally or by the signing runner.
- Publish the small signed update feed directly to Cloudflare Pages while
  serving release archives from an immutable public GitHub distribution tag, so an unreliable
  Pages large-file upload or hosted Actions billing failure cannot strand the
  live update feed.

## [1.17.0] - 2026-08-05

### Added

- Add Raycast migration for encrypted configuration, shortcuts, clipboard history, snippets, quick links, preferences, and conflict-aware import.
- Add a trusted offline Raycast command host with native List, Detail, Form, Action Panel, clipboard, storage, navigation, and user-confirmed URL actions.
- Add pinned Node 25 tooling, pure-JavaScript dependency resolution, source-policy scanning, isolated sessions, and packaged fresh-profile verification.

### Fixed

- Preserve physical runtime paths and compiler context across signed packaged launches.
- Harden Raycast compatibility checks, Swift 6 inference, startup framing, and fresh-profile probes.
- Keep imported Raycast commands' native clipboard replies working when Node and macOS canonicalize the same UUID with different letter case.
- Keep unsupported network, AI, native-module, arbitrary-shell, and unsafe UI capabilities rejected by the offline policy.

All notable changes to Coco, newest first. One `## [version] - date`
section per release; the maintainer adds the new section in the release
commit *before* tagging `vX.Y.Z`.

## [1.16.7] - 2026-08-02
### Fixed
- Coco no longer asks an already-activated Mac to activate again after it
  has been offline for a while. Activation codes grant a perpetual license,
  but it was still being held to a 72-hour offline check-in window.
- Coco now re-checks its license as soon as the network comes back, instead
  of only at launch.
- When the license is fine but the license server can't be reached, the
  prompt says so and offers a retry rather than claiming the trial ended.

## [1.16.6] - 2026-07-16
### Fixed
- Coco no longer quits when macOS 27 beta (26A5378n) throws an exception
  inside the menu-bar status-item wake path after lid-open/unlock. The
  ViewBridge `NSRemoteView` exception is now caught and logged instead of
  aborting the app.

## [1.16.4] - 2026-07-10
### Fixed
- Lid-close Keep Awake now directs users to enable **Coco** under macOS
  Background Items instead of asking them to find an invisible helper.
- Recovery reports whether an official signed update, macOS approval, or a
  helper reinstall is required; it no longer fails silently.
- Stable releases require a matching Developer ID signature for both Coco and
  its privileged helper, preventing public packages that cannot use lid-close
  protection.

### Changed
- Lid-close protection now relies on the MacBook's natural panel-off behavior
  and no longer forces a display-power transition that could leave audio or
  microphone hardware stuck after reopening the lid.
- Idle screen style is configured separately from lid-close protection.

## [1.7.0] - 2026-05-19
### Added
- Native macOS Liquid Glass refractive rim on the launcher panel.
- Calculator accepts a standalone `x` as multiply (`2x3`, `2 x 3`).
### Changed
- Mode switch resolves its colors live for light/dark appearance.
- Action menu no longer dims the result list.
### Fixed
- "Already up to date" / canceled update checks no longer surface as failures.
